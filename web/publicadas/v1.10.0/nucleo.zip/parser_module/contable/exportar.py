"""Excel con tu estructura: por mes una hoja «BALANCE x CTA <MES>» y una «MOVIMIENTOS <MES>» (mismas columnas y colores), y una hoja «RESULTADO»."""
from __future__ import annotations
import hashlib, io, json
from pathlib import Path
from collections import defaultdict
from datetime import date, datetime
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as L
from . import puc

MESES = ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"]
HEAD = ["Fecha", "Código cuenta contable", "Nombre cuenta contable", "Tercero", "Descripción", "Movimiento débito", "Movimiento crédito", "", "Reporta", "Medio de Pago"]
VERDE, ROSA, AZUL = "E2EFDA", "FCE4D6", "D9ECFC"
_f = lambda c: PatternFill("solid", fgColor=c)
FINO = Border(bottom=Side(style="hair", color="BFBFBF"))


DATOS_HEAD = {"fecha": "Fecha", "archivo": "Archivo de origen", "tipo": "Tipo", "numero": "Número", "tercero": "Tercero", "detalle": "Detalle", "valor": "Valor",
              "medio": "Medio de pago", "cuenta": "Cuenta", "estado": "Estado", "aviso": "Aviso", "propina": "Propina", "domicilio": "Domicilio", "bloque": "Asiento", "id": "Id", "recibo": "Recibo", "motivo": "Motivo si es dudoso", "medio_detalle": "Medio según el papel"}
AMARILLO = "FFF2CC"
NARANJA = "F8CBAD"   # FIX-12: recibo dudoso, distinto del amarillo de cualquier aviso


def texto(c):
    """FIX-12 (CWE-1236): texto libre (papel leído, digitado) que empieza por = + - @ queda como texto, no como fórmula activa."""
    if isinstance(c.value, str) and c.value[:1] in ("=", "+", "-", "@", "\t", "\r"): c.data_type = "s"; c.quotePrefix = True
    return c


D = "'DATOS OCR'!"
DC = {k: L(i) for i, k in enumerate(DATOS_HEAD, 1)}   # columna de cada campo en DATOS OCR
NOTAS_DATOS = ["Los importes de MOVIMIENTOS son fórmulas sobre la hoja DATOS OCR: corrige allí un valor, una cuenta o un estado y el libro se recalcula al abrirlo en Excel.",
               "Solo suman las filas con estado «ok». Si corriges una cuenta o un medio que no tiene fila en MOVIMIENTOS (un grupo nuevo), ese valor no entra: corrígelo en la app y vuelve a exportar.",
               "La propina y el domicilio de cada venta van como valor fijo: si corriges el valor de una venta, corrige también su propina y su domicilio."]


def _criterio(v) -> str:
    """Criterio literal de SUMIFS: comodines escapados y un «=» delante si el texto empieza con un operador (ADR-002: nunca una celda vacía)."""
    s, op = str(v), ""
    if s.startswith("<>"): s, op = s[2:], "<>"
    s = s.replace("~", "~~").replace("*", "~*").replace("?", "~?")
    if not op and s[:1] in ("<", ">", "="): op = "="
    return '"' + (op + s).replace('"', '""') + '"'


def formula(fx, fila: int, ref_fila, ref_dato) -> str:
    """fx de asientos.construir → texto de la fórmula (sin «=»). ref_fila(j) y ref_dato(i) dan la celda (o el valor) de otra fila del día o de DATOS OCR."""
    op, *a = fx
    if op == "sum":
        col, crit = a
        est = _criterio(crit["estado"]) if "estado" in crit else '"ok"'   # M-6: «en extracto» para la propina/domicilio que cubre el extracto
        pares = [(DC["fecha"], f"$A{fila}"), (DC["estado"], est)] + [(DC[k], _criterio(v)) for k, v in crit.items() if k != "estado"]
        return f"SUMIFS({D}{DC[col]}:{DC[col]}," + ",".join(f"{D}{c}:{c},{x}" for c, x in pares) + ")"
    if op == "dato": return ref_dato(a[0])
    if op == "fila": return ref_fila(a[0])
    t = [formula(x, fila, ref_fila, ref_dato) for x in a]
    if op == "min": return f"MIN({','.join(t)})"
    if op == "+": return "+".join(t) if len(t) > 1 else t[0]
    if op == "-": return t[0] + "".join(f"-({x})" if "+" in x or "-" in x else f"-{x}" for x in t[1:])
    raise ValueError(f"fx desconocido: {op}")


def hoja_datos(wb, datos: dict) -> dict:
    """DATOS OCR (R9, ADR-002), primera hoja: una fila por papel y medio de pago. Un recibo dudoso va en naranja; lo demás que no está «ok» o trae aviso, en amarillo.
    Devuelve {fecha: fila de la hoja donde empieza ese día} para que MOVIMIENTOS apunte a sus datos."""
    ws = wb.create_sheet("DATOS OCR"); ws.append(list(DATOS_HEAD.values())); inicio = {}
    for c in ws[1]: c.font = Font(bold=True); c.fill = _f(AZUL); c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for f in sorted(datos):
        inicio[f] = ws.max_row + 1
        for r in datos[f]:
            ws.append([date.fromisoformat(r["fecha"]) if k == "fecha" else (int(r[k]) if k == "cuenta" and str(r[k]).isdigit() else (r[k] if r[k] != "" else None)) for k in DATOS_HEAD])
            k = ws.max_row; ws.cell(k, 1).number_format = "dd/mm/yyyy"
            for c in ws[k]: texto(c)
            for i in (7, 12, 13): ws.cell(k, i).number_format = '$ #,##0;-$ #,##0;"$ -"'
            if r["recibo"] == "dudoso":
                for c in ws[k]: c.fill = _f(NARANJA)
            elif r["estado"] != "ok" or r["aviso"]:
                for c in ws[k]: c.fill = _f(AMARILLO)
    for i, w in enumerate([12, 40, 14, 10, 26, 30, 14, 16, 11, 12, 36, 12, 12, 10, 10, 12, 44], 1): ws.column_dimensions[L(i)].width = w
    ws.freeze_panes = "A2"; ws.auto_filter.ref = f"A1:{L(len(DATOS_HEAD))}{max(ws.max_row, 2)}"
    return inicio


PLAN = json.loads((Path(__file__).with_name("plan_de_cuentas.json")).read_text(encoding="utf8"))
CLASES = ["ACTIVO", "PASIVO", "PATRIMONIO", "INGRESOS", "GASTOS", "COSTOS"]
PESOS = '#,##0;[Red]-#,##0;"-"'


def hoja_balance(wb, nom_mov: str, y: int, m: int, filas: list, negocio: str, nit: str, previa: str | None) -> str:
    """Balance de prueba por cuenta del mes, con la misma forma que «BALANCE x CTA <MES>» del Excel manual: todas las cuentas del plan
    más las que use el mes; débito/crédito = SUMIFS sobre MOVIMIENTOS (por la celda de la fila, no la columna entera); saldo inicial = saldo
    final del mes anterior si está en el mismo archivo, si no 0. Devuelve el nombre de la hoja."""
    nom = f"BALANCE x CTA {MESES[m - 1]}"
    ws = wb.create_sheet(nom, wb.sheetnames.index(nom_mov))
    q, p = f"'{nom_mov}'!", f"'{previa}'!" if previa else None
    nombres = {c["codigo"]: c["nombre"] for c in PLAN if not c["nombre"].startswith("(")}
    for c in PLAN: nombres.setdefault(c["codigo"], c.get("nombre_diario") or c["codigo"])
    for f in filas: nombres.setdefault(str(f["codigo"]), f.get("nombre") or puc.nombre(f["codigo"]) or str(f["codigo"]))
    cods = sorted(k for k in nombres if k.isdigit())
    ult = max(f["fecha"] for f in filas)
    ws["A2"] = "Balance de prueba por tercero"; ws["A3"] = negocio or "(nombre del negocio)"; ws["A4"] = f"NIT {nit}" if nit else "(NIT)"
    ws["A5"] = f"A {MESES[m - 1].capitalize()} {int(ult[8:]):d} de {y}"
    for r in (2, 3): ws[f"A{r}"].font = Font(bold=True)
    if not p:
        ws["A6"] = "Saldo inicial en 0: es el primer mes del archivo. Copia en la columna E los saldos finales del mes anterior."; ws["A6"].font = Font(italic=True, color="9C5700")
    for i, h in enumerate(["Clase", "Mayor", "Código cuenta contable", "Nombre cuenta contable", "Saldo inicial", "Movimiento débito", "Movimiento crédito", "Saldo final"], 1):
        c = ws.cell(8, i, h); c.font = Font(bold=True); c.fill = _f(AZUL); c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[8].height = 32
    for k, cod in enumerate(cods, 9):
        ws.cell(k, 1, cod[0]); ws.cell(k, 2, cod[:4]); ws.cell(k, 3, int(cod)); texto(ws.cell(k, 4, nombres[cod]))
        ws.cell(k, 5, f"=SUMIFS({p}H:H,{p}C:C,$C{k})" if p else 0)
        ws.cell(k, 6, f"=SUMIFS({q}F:F,{q}B:B,$C{k})"); ws.cell(k, 7, f"=SUMIFS({q}G:G,{q}B:B,$C{k})"); ws.cell(k, 8, f"=E{k}+F{k}-G{k}")
        for i in range(5, 9): ws.cell(k, i).number_format = PESOS
        for i in range(1, 9): ws.cell(k, i).border = FINO
    t = 9 + len(cods)
    ws.cell(t, 1, "Total general").font = Font(bold=True)
    for i in range(5, 9): c = ws.cell(t, i, f"=SUM({L(i)}9:{L(i)}{t - 1})"); c.number_format = PESOS; c.font = Font(bold=True)
    ws.cell(t + 1, 4, "Diferencia con MOVIMIENTOS (debe dar 0)").alignment = Alignment(horizontal="right")
    ws.cell(t + 1, 6, f"=F{t}-{q}F7").number_format = PESOS; ws.cell(t + 1, 7, f"=G{t}-{q}G7").number_format = PESOS
    for k, cl in enumerate(CLASES, 1):   # resumen por clase, como J1:M7 del manual
        ws.cell(k, 10, str(k)); ws.cell(k, 11, cl); ws.cell(k, 12, f'=SUMIFS(H:H,A:A,"{k}")').number_format = PESOS
    ws.cell(7, 11, "RESULTADO").font = Font(bold=True); ws.cell(7, 12, "=L4+L5+L6").number_format = PESOS
    for i, w in enumerate([7, 8, 14, 42, 16, 16, 16, 16, 3, 5, 14, 16], 1): ws.column_dimensions[L(i)].width = w
    ws.freeze_panes = "A9"
    return nom


def libro_a_excel(dias: dict, negocio: str = "", nit: str = "", datos: dict | None = None, avisos: list | None = None) -> bytes:
    """dias: {'2026-09-12': [fila, …]} con filas de asientos.construir(); datos: {'2026-09-12': construir()['datos']} para la hoja DATOS OCR.
    Con datos, cada importe es una fórmula sobre DATOS OCR (ADR-002); filas y datos de un día deben salir del mismo construir().
    avisos: líneas extra para la hoja AVISOS (p. ej. días que cambiaron desde que se confirmaron)."""
    wb = Workbook(); wb.remove(wb.active)
    inicio = hoja_datos(wb, datos) if datos else {}
    por_mes, avisos = defaultdict(list), list(avisos or [])
    for f in sorted(dias):
        for j, x in enumerate(dias[f]):   # R10: una fila sin código de cuenta no entra a MOVIMIENTOS; se avisa
            if str(x.get("codigo") or "").strip(): por_mes[f[:7]].append(dict(x, _j=j))
            else: avisos.append(f"{f}: fila sin código de cuenta ({x.get('descripcion') or x.get('nombre') or 's/d'}, débito {x.get('debito') or 0:,}, crédito {x.get('credito') or 0:,}); no se exportó".replace(",", "."))
    usados = sorted({str(x["codigo"]) for fs in por_mes.values() for x in fs})
    for c in usados:   # códigos según el PUC (puc.com.co): una cuenta o subcuenta que no existe se avisa, no se bloquea
        estado, txt = puc.revisar(c)
        if estado == "no existe": avisos.append(f"PUC: {txt}")
    hojas = []
    for ym in sorted(por_mes):
        y, m = int(ym[:4]), int(ym[5:7]); nom = f"MOVIMIENTOS {MESES[m - 1]}"; hojas.append((nom, y, m))
        ws = wb.create_sheet(nom); filas = por_mes[ym]; ult = max(f["fecha"] for f in filas)
        ws["A2"] = "Balance de prueba por tercero"; ws["A3"] = negocio or "(nombre del negocio)"; ws["A4"] = f"NIT {nit}" if nit else "(NIT)"
        ws["A5"] = f"A {int(ult[8:]):d} de {MESES[m - 1].capitalize()} de {y}"
        for r in (2, 3): ws[f"A{r}"].font = Font(bold=True)
        n = len(filas); ult_fila = 8 + n
        ws["E7"] = "Total del mes"; ws["E7"].font = Font(bold=True); ws["E7"].alignment = Alignment(horizontal="right")
        ws["F7"] = f"=SUM(F9:F{ult_fila})"; ws["G7"] = f"=SUM(G9:G{ult_fila})"; ws["I7"] = "=F7-G7"
        for c in ("F7", "G7", "I7"): ws[c].number_format = '$ #,##0;[Red]-$ #,##0'; ws[c].font = Font(bold=True)
        for i, h in enumerate(HEAD, 1):
            c = ws.cell(8, i, h or None); c.font = Font(bold=True); c.fill = _f(AZUL); c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.row_dimensions[8].height = 32
        filas = sorted(filas, key=lambda x: (x["fecha"], 0))   # sorted es estable: conserva el orden de cada día
        pos = {(f["fecha"], f["_j"]): (k, f) for k, f in enumerate(filas, 9)}
        def ref_fila(fe, j):   # celda del importe de otra fila del mismo día (contrapartida); si no se exportó, su valor
            k, g = pos.get((fe, j), (None, dias[fe][j]))
            lado = (g.get("fx") or ["debito"])[0]
            return f"{'G' if lado == 'credito' else 'F'}{k}" if k else str(g[lado] or 0)
        for k, f in enumerate(filas, 9):
            imp = [f["debito"] or 0, f["credito"] or 0]
            if f.get("fx") and f["fecha"] in inicio:   # ADR-002: el importe sale de DATOS OCR
                base, fe = inicio[f["fecha"]], f["fecha"]
                imp[f["fx"][0] == "credito"] = "=" + formula(f["fx"][1], k, lambda j: ref_fila(fe, j), lambda i: f'IF({D}{DC["estado"]}{base + i}="ok",{D}{DC["valor"]}{base + i},0)')   # FIX-2: solo suma si está «ok»
            v = [date.fromisoformat(f["fecha"]), int(f["codigo"]) if str(f["codigo"]).isdigit() else (f["codigo"] or None), f["nombre"], f["tercero"], f["descripcion"],
                 *imp, None, f["reporta"] or None, f["medio"] or None]
            for i, x in enumerate(v, 1):
                c = ws.cell(k, i, x); c.border = FINO
                if i not in (6, 7): texto(c)   # F/G sí pueden ser fórmulas (ADR-002)
                c.fill = _f(VERDE if str(f["codigo"]).startswith("4") or f.get("grupo") == "venta" else ROSA)
            ws.cell(k, 1).number_format = "dd/mm/yyyy"; ws.cell(k, 1).alignment = Alignment(horizontal="center")
            for i in (6, 7): ws.cell(k, i).number_format = '$ #,##0;-$ #,##0;"$ -"'
        for i, w in enumerate([12, 14, 34, 28, 42, 17, 17, 3, 11, 18], 1): ws.column_dimensions[L(i)].width = w
        ws.freeze_panes = "A9"; ws.auto_filter.ref = f"A8:J{ult_fila}"
    previa = None
    for nom, y, m in hojas:   # «BALANCE x CTA <MES>» justo antes de su MOVIMIENTOS, como en el Excel manual
        previa =hoja_balance(wb, nom, y, m, por_mes[f"{y:04d}-{m:02d}"], negocio, nit, previa)
    rs = wb.create_sheet("RESULTADO")
    rs.append(["Mes", "Ingresos (4…)", "Gastos (5…)", "Ganancia (+) / Pérdida (−)"])
    for c in rs[1]: c.font = Font(bold=True); c.fill = _f(AZUL); c.alignment = Alignment(horizontal="center", wrap_text=True)
    for k, (nom, y, m) in enumerate(hojas, 2):
        q = f"'{nom}'!"
        rs.cell(k, 1, f"{MESES[m - 1].capitalize()} {y}")
        rs.cell(k, 2, f'=SUMIFS({q}G:G,{q}B:B,">=40000000",{q}B:B,"<50000000")-SUMIFS({q}F:F,{q}B:B,">=40000000",{q}B:B,"<50000000")')
        rs.cell(k, 3, f'=SUMIFS({q}F:F,{q}B:B,">=50000000",{q}B:B,"<70000000")-SUMIFS({q}G:G,{q}B:B,">=50000000",{q}B:B,"<70000000")')
        rs.cell(k, 4, f"=B{k}-C{k}")
        for c in (2, 3, 4): rs.cell(k, c).number_format = '$ #,##0;[Red]-$ #,##0'
    t = len(hojas) + 2
    rs.cell(t, 1, "TOTAL")
    for c in (2, 3, 4): rs.cell(t, c, f"=SUM({L(c)}2:{L(c)}{t - 1})").number_format = '$ #,##0;[Red]-$ #,##0'
    for c in rs[t]: c.font = Font(bold=True); c.fill = _f("EEF6FE")
    rs.cell(t + 2, 1, "Ojo: los insumos que compras (cocina, barra, empaques) quedan como activo y no se descuentan aquí. Para una ganancia real, resta el costo de lo consumido con el inventario final de cada mes.")
    rs.cell(t + 2, 1).alignment = Alignment(wrap_text=True, vertical="top"); rs.merge_cells(start_row=t + 2, start_column=1, end_row=t + 2, end_column=4); rs.row_dimensions[t + 2].height = 48
    for i, w in enumerate([22, 20, 20, 26], 1): rs.column_dimensions[L(i)].width = w
    if not hojas: wb.remove(rs); wb.create_sheet("MOVIMIENTOS")
    if avisos or inicio:
        av = wb.create_sheet("AVISOS"); av["A1"] = "Avisos de exportación"; av["A1"].font = Font(bold=True); av.column_dimensions["A"].width = 110
        for a in avisos + (NOTAS_DATOS if inicio else []): av.append([a]); texto(av.cell(av.max_row, 1))
    buf = io.BytesIO(); wb.save(buf); return buf.getvalue()


# ═════════════ ADR-004: archivo crudo para llevar lo leído a un PC sin OCR ═════════════
FORMATO_CRUDO, VERSION_CRUDO = "ingresos-crudo", 1
CAMPOS_CRUDO = ("fecha", "documentos", "banco", "cierre", "guardado")   # solo lo leído; filas, cruces y totales se recalculan al importar (ADR-002)


def huella(dias: list) -> str:
    """sha256 de los días serializados con claves ordenadas: detecta un archivo cortado o editado a mano."""
    return hashlib.sha256(json.dumps(dias, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def crudo(lib: dict, desde: str = "", hasta: str = "") -> bytes:
    """libro.json → .json {formato, version, exportado, desde, hasta, sha256, dias} con los días del rango (vacío = sin límite)."""
    dias = [{k: lib[f].get(k, {} if k in ("banco", "cierre") else [] if k == "documentos" else "") for k in CAMPOS_CRUDO} | {"fecha": f}
            for f in sorted(lib) if (not desde or f >= desde) and (not hasta or f <= hasta)]
    return json.dumps(dict(formato=FORMATO_CRUDO, version=VERSION_CRUDO, exportado=datetime.now().isoformat(timespec="seconds"), desde=desde, hasta=hasta,
                           sha256=huella(dias), dias=dias), ensure_ascii=False, indent=1).encode("utf-8")


TIPOS_CRUDO = {"cierre", "venta", "gasto_caja", "caja_menor_manuscrito", "factura", "otro", "faltante"}   # los de documentos.PARSERS más «otro» y el marcador de ADR-008
MAX_VALOR, MAX_TEXTO, MAX_DOCS, MAX_HONDO = 10**10, 20000, 2000, 6   # texto OCR real ya llega a ~4.000 (FIX-14)


class CrudoInvalido(ValueError):
    """El archivo entero no sirve (no es JSON, otro formato o versión, sha256 distinta): no se escribe nada."""


def _malo(v, ruta: str, hondo: int = 0) -> str:
    """Primer valor fuera de los topes de 03 §10 (números |v| ≤ 10^10, textos ≤ 20.000), o «» si todo está bien.
    Negativos sí: el cierre guarda el faltante como faltante_impreso < 0 (documentos.py, FIX-13)."""
    if hondo > MAX_HONDO: return f"{ruta}: demasiado anidado"
    if v is None or isinstance(v, bool): return ""
    if isinstance(v, (int, float)):
        return "" if v == v and -MAX_VALOR <= v <= MAX_VALOR else f"{ruta}: valor {v} fuera de ±10.000.000.000"
    if isinstance(v, str): return "" if len(v) <= MAX_TEXTO else f"{ruta}: texto de {len(v)} caracteres (máx. {MAX_TEXTO})"
    if isinstance(v, list): return next((m for i, x in enumerate(v) if (m := _malo(x, f"{ruta}[{i}]", hondo + 1))), "")
    if isinstance(v, dict): return next((m for k, x in v.items() if (m := _malo(x, f"{ruta}.{k}", hondo + 1))), "")
    return f"{ruta}: tipo de dato desconocido"


def _motivo_dia(d) -> str:
    if not isinstance(d, dict): return "el día no es un objeto"
    f = d.get("fecha")
    try: ok = isinstance(f, str) and len(f) == 10 and date.fromisoformat(f).isoformat() == f
    except ValueError: ok = False
    if not ok: return f"fecha inválida: {str(f)[:20]!r}"
    docs = d.get("documentos")
    if not isinstance(docs, list): return "«documentos» no es una lista"
    if len(docs) > MAX_DOCS: return f"{len(docs)} documentos (máx. {MAX_DOCS})"
    ids = set()
    for i, x in enumerate(docs):
        if not isinstance(x, dict): return f"documento {i + 1}: no es un objeto"
        if x.get("tipo") not in TIPOS_CRUDO: return f"documento {i + 1}: tipo desconocido {str(x.get('tipo'))[:30]!r}"
        if not isinstance(x.get("id"), str) or not x["id"]: return f"documento {i + 1}: sin id"
        if x["id"] in ids: return f"documento {i + 1}: id {x['id'][:40]!r} repetido en el día"   # M-2
        if x["tipo"] != "cierre" and isinstance(x.get("valor"), (int, float)) and not isinstance(x["valor"], bool) and x["valor"] < 0:
            return f"documento {i + 1}: valor negativo ({x['valor']}); solo el cierre lleva negativos (faltante)"   # M-1
        ids.add(x["id"])
        if m := _malo(x, f"documento {i + 1}"): return m
    for k in ("banco", "cierre"):
        if not isinstance(d.get(k, {}), dict): return f"«{k}» no es un objeto"
        if m := _malo(d.get(k, {}), k): return m
    if not isinstance(d.get("guardado", ""), str) or len(d.get("guardado", "")) > 40: return "«guardado» inválido"
    return ""


def leer_crudo(data: bytes) -> tuple[list, list]:
    """Archivo crudo (ADR-004) → (días válidos, inválidos [{fecha, motivo}]). Valida en el orden de 03 §10: JSON, formato, versión y
    sha256 (si falla, CrudoInvalido y no se usa nada); después cada día. Un día malo no entra pero sale en la lista (R10)."""
    try: j = json.loads(data.decode("utf-8-sig"))   # json, nunca pickle ni eval: el archivo viene de otro equipo
    except (UnicodeDecodeError, ValueError, RecursionError): raise CrudoInvalido("El archivo no es un .json válido (¿está cortado?)") from None
    if not isinstance(j, dict) or j.get("formato") != FORMATO_CRUDO:
        raise CrudoInvalido("El archivo no es de datos crudos de Ingresos (falta «formato: ingresos-crudo»)")
    if j.get("version") != VERSION_CRUDO:
        raise CrudoInvalido(f"El archivo es de la versión {str(j.get('version'))[:10]} y esta app lee la versión {VERSION_CRUDO}: "
                            "exporte de nuevo con la misma versión de la app en los dos PCs")
    dias = j.get("dias")
    if not isinstance(dias, list) or j.get("sha256") != huella(dias):
        raise CrudoInvalido("La huella sha256 no coincide: el archivo se cortó o se editó a mano. Exporte de nuevo")
    buenos, malos, vistos = [], [], set()
    for d in dias:
        m = _motivo_dia(d) or ("fecha repetida en el archivo" if d["fecha"] in vistos else "")
        f = d.get("fecha") if isinstance(d, dict) and isinstance(d.get("fecha"), str) else "?"
        if m: malos.append(dict(fecha=f[:20], motivo=m)); continue
        vistos.add(f)
        buenos.append(dict(fecha=f, documentos=d["documentos"], banco=d.get("banco") or {}, cierre=d.get("cierre") or {}, guardado=d.get("guardado") or ""))
    return buenos, malos
